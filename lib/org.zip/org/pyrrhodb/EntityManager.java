// Pyrrho Database Engine by Malcolm Crowe at the University of the West of Scotland
// (c) Malcolm Crowe, University of the West of Scotland 2004-2011
//
// This software is without support and no liability for damage consequential to use
// You can view and test this code
// All other use or distribution or the construction of any product incorporating this technology
// requires a license from the University of the West of Scotland

// OPEN SOURCE EDITIONS

package org.pyrrhodb;

import java.io.IOException;
import java.lang.reflect.*;
import java.util.*;

// This class implements the EntityManager interface described in the 
// Java EE 5 SDK specification
public class EntityManager {
    // connection string properties
    Map<String,String> properties = new HashMap<String,String>();
    // a catalogue of entities used in this em
    Map<Object, EntityInfo> entities = new HashMap<Object,EntityInfo>();
    // another index of EntityInfo
    Map<EntityFinder,EntityInfo> cache = new HashMap<EntityFinder,EntityInfo>();
    // a catalogue of entity types used in this em
    Map<String, EntityType> types = new HashMap<String,EntityType>();
    // the current transaction if any
    EntityTransaction transaction = null;
    // the current Pyrrho DBMS connection
    Connection connection = null;
    // the state of this em
    boolean closed = false;
    /**
     * Creates a new instance of EntityManager
     */
    EntityManager(Map cdata) {
        for (Object k : cdata.keySet())
            properties.put(k.toString(),cdata.get(k).toString());
        entities = new HashMap<Object,EntityInfo>();
        types = new HashMap<String,EntityType>();
    }
    // create an em for a given persistence unit
    public EntityManager(PersistenceUnit ctx,Map map) {
            properties.put("Files",ctx.name());
            for (PersistenceProperty p:ctx.properties())
                properties.put(p.name(),p.value());
            Iterator it = map.entrySet().iterator();
            while (it.hasNext())
            {
                Map.Entry en = (Map.Entry)it.next();
                properties.put((String)en.getKey(),(String)en.getValue());
            }
    }
    
    // Connect to the Pyrrho DBMS
    void Connect() throws IllegalStateException,IOException {
        if (closed)
            throw new IllegalStateException();
        if (connection!=null)
            return;
        connection = new Connection(properties);
    }
    // Implementation of Java EE 5 persist function
    public void persist(Object entity) throws EntityExistsException,
            IllegalStateException,IllegalArgumentException,
            IllegalAccessException, InvocationTargetException, InstantiationException {
        if (closed)
            throw new IllegalStateException();
        if (entities.containsKey(entity))
            throw new EntityExistsException();
        EntityType tp = ETfor(entity.getClass());
        EntityInfo ei = new EntityInfo(tp,entity);
        EntityFinder ef = EFfor(entity,tp);
        ei.setCache(tp,entity);
        if (cache.containsKey(ef))
            throw new EntityExistsException();
        entities.put(entity,ei);
        cache.put(ef,ei);
    }
    // Implementation of Java EE5 merge function
    public <T> T merge(T entity) throws IllegalStateException,
            IllegalArgumentException,EntityExistsException,
            IllegalAccessException, InvocationTargetException, InstantiationException
            {
        if (closed)
            throw new IllegalStateException();
        EntityInfo ei = entities.get(entity);
        if (ei==null) {
            persist(entity);
            return entity;
        }
        EntityType et = ETfor(entity.getClass());
        EntityFinder ef = EFfor(entity,et);
        T next = (T)cache.get(ef).entity;
        if (next!=null && next!=entity) {
            EntityInfo nei = entities.get(next);
            nei.setCache(et,entity);
            return next;
        }
        ei.setCache(et,entity);
        return entity;
    }
    // Implementation of Java EE 5 remove function
    public void remove(Object entity) throws IllegalStateException {
        if (closed)
            throw new IllegalStateException();
        entities.remove(entity);
    }
    // Implementation of Java EE 5 find function
    public <T> T find(Class<T> cl, Object obj) throws IllegalStateException, IllegalArgumentException, NoResultException  {
        try {
            Connect();
            EntityType tp = ETfor(cl);
            if (tp==null)
                throw new IllegalArgumentException();
            String a = "a";
            if (a.equals(tp.table))
                a = "b";
            Object[] r = connection.getResults(this,"select "+a+" from \""+tp.table+
                    "\" "+a+" where \""+tp.key.name+"\"="+formatColumn(tp.key,obj),
                    0,1000000);
            if (r==null || r.length==0)
                throw new NoResultException();
            return (T)r[0];
        } catch (IOException ex) {
            String msg = ex.getMessage();
            throw new IllegalArgumentException(msg);
        } catch (PersistenceException ex) {
            String msg = ex.getMessage();
            throw new IllegalArgumentException(msg);
        }
    }
    // Construct an entity finder for a given Entity type and an entity of that type
    EntityFinder EFfor(Object en,EntityType tp) throws IllegalArgumentException,
            IllegalAccessException, InvocationTargetException {
        EntityFinder ef = new EntityFinder();
        ef.type = en.getClass();
        if (tp==null)
            throw new IllegalArgumentException();
        if (tp.key.getMeth!=null)
            ef.key = tp.key.getMeth.invoke(en);
        else
            ef.key = tp.key.field.get(en);
        return ef;
    }
    // Return an Entity type for av given class
    EntityType ETfor(Class cl) {
        try {
            EntityType tp = types.get(cl);
            if (tp==null) {
                Entity e = (Entity)cl.getAnnotation(Entity.class);
                String tn = e.name();
                if (tn.equals(""))
                    tn = cl.getName();
                int ix = tn.lastIndexOf('.');
                if (ix>=0)
                    tn = tn.substring(ix+1);
                Method km = null;
                Field kf = null;
                ArrayList al = new ArrayList();
                for (Method m: cl.getDeclaredMethods()) {
                    String mn = m.getName();
                    if (!mn.startsWith("get"))
                        continue;
                    if (m.isAnnotationPresent(Id.class))
                        km = m;
                    if (m.getAnnotations().length!=0)
                    {
                        String n = "set"+mn.substring(3);
                        Class typ = m.getReturnType();
                        Method sm = cl.getMethod(n,typ);
                        al.add(new FieldInfo(m,sm));
                    }
                }
                for (Field f: cl.getDeclaredFields()) {
                    if (f.isAnnotationPresent(Id.class))
                        kf = f;
                    if (f.getAnnotations().length!=0)
                        al.add(new FieldInfo(f));
                }
                FieldInfo[] cols = new FieldInfo[al.size()];
                for (int j=0;j<al.size();j++) 
                {
                    // insertion sort
                    FieldInfo fi = (FieldInfo)al.get(j);
                    int i;
                    for (i=j-1;i>=0 && cols[i].name.toUpperCase().compareTo(fi.name.toUpperCase())>0;i--) {
                        cols[i+1] = cols[i];
                    }
                    cols[i+1] = fi;
                }
                if (km!=null)
                    tp = new EntityType(cl,tn,new FieldInfo(km,null),cols);
                if (kf!=null)
                    tp = new EntityType(cl,tn,new FieldInfo(kf),cols);
                types.put(cl.getName(),tp);
            }
            return tp;
        } catch(Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    // format a field value by adding single quotes for Strings
    String formatColumn(FieldInfo c,Object v){
         if (c.type==String.class)
            return "'"+v.toString()+"'";
        return v.toString();
    }
    // Get a value given a reference
    public <T> T getReference(Class<T> cl , Object obj) throws
            IllegalStateException, IllegalArgumentException,
            InstantiationException, IllegalAccessException,
            InvocationTargetException  
    {
        if (closed)
            throw new IllegalStateException();
        EntityType tp = ETfor(cl);
        if (tp==null)
            throw new IllegalArgumentException();
        EntityFinder ef = new EntityFinder(cl,obj);
        T entity = (T)cache.get(ef);
        if (entity==null)
        {
            entity = cl.newInstance();
            tp.key.getMeth.invoke(entity,obj);
            EntityInfo ei = new EntityInfo(tp,entity);
            ei.setCache(tp,entity);
            cache.put(ef,ei);
            entities.put(entity,ei);
        }
        return entity;
    }
    // flush persistent objects to the database
    public void flush() throws IllegalAccessException, InvocationTargetException, IOException, PersistenceException {
        for (Object en: entities.keySet())
        {
            EntityInfo ei = entities.get(en);
            EntityType et = ei.type;
            boolean changed = false; 
            String str = "update "+et.table;
            String val = ") values ";
            String comma = "(";
            for (int j = 0;j<et.cols.length;j++)
            {
                FieldInfo fi = et.cols[j];
                Object ol = fi.get(ei.entity);
                Object nw = fi.get(en);
                if (ol!=nw)
                {
                    str += comma + fi.name;
                    val += comma + formatColumn(fi,nw);
                    comma = ",";
                    changed = true;
                }
            }
            if (changed)
            {
                Object key = et.key.get(ei.entity);
                String where = ")" + et.key.name+"="+formatColumn(et.key,key);
                connection.act(this,str+val+where);
            }
        }
    }
    
    public void setFlushMode(FlushModeType flushMode) {
    }
    
    public FlushModeType getFlushMode() {
        return FlushModeType.AUTO;
    }
    
    public void refresh(Object entity) throws IllegalAccessException, IOException, PersistenceException, InvocationTargetException {
        EntityInfo ei = entities.get(entity);
        EntityType et = ei.type;
        Object key = et.key.get(ei.entity);
        ei.entity = et.clas.cast(connection.getResults(this,"select a from"
                +et.table+" a where "+et.key.name+"="+formatColumn(et.key,key),
                0,100000)[0]);
        for (int j=0;j<et.cols.length;j++)
            et.cols[j].set(entity,et.cols[j].get(ei.entity));
    }
    
    public void clear() {
        entities.clear();
    }
    
    public boolean contains(Object entity) {
        return entities.containsKey(entity);
    }
    
    public Query createQuery(String qlString) throws IOException {
        Connect();
        return new Query(this,"",true,qlString,Object.class);
    }
    
    public Query createNamedQuery(String name) throws IOException {
        Connect();
        return new Query(this,name,false,"",Object.class);
    }
    
    public Query createNativeQuery(String sqlString) throws IOException {
        Connect();
        return new Query(this,"",false,sqlString,Object.class);
    }
    
    public Query createNativeQuery(String sqlString, Class resultClass) throws IOException {
        Connect();
        return new Query(this,"",false,sqlString,resultClass);
    }
    
    public Query createNativeQuery(String sqlString, String resultSetMapping) {
        return null;
    }
    
    public void joinTransaction() {
        transaction = new EntityTransaction(this);
    }
    
    public Object getDelegate() {
        return null;
    }
    
    public void close() {
    }
    
    public boolean isOpen() {
        return false;
    }
    
    public EntityTransaction getTransaction() {
        return null;
    }
    
}
