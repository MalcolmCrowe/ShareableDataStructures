/*
 * EntityState.java
 *
 * Created on 23 November 2006, 21:25
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package org.pyrrhodb;

/**
 *
 * @author Malcolm
 */
public enum EntityState { NEW, REFERENCE, SAVED, DETACHED, DELETED }

