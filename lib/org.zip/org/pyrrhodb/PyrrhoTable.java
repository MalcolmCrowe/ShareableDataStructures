/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package org.pyrrhodb;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author Malcolm
 */
public class PyrrhoTable {
    PyrrhoColumn[] cols = null;
    List<PyrrhoRow> Rows = new ArrayList<PyrrhoRow>();
    PyrrhoTable(int n)
    {
        cols = new PyrrhoColumn[n]; 
    }

}
