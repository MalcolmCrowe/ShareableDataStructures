/*
 * Query.java
 *
 * Created on 23 November 2006, 21:43
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package org.pyrrhodb;

import java.io.IOException;
import java.util.*;

/**
 *
 * @author Malcolm
 */
public class Query  {
    EntityManager em;
    String name;
    String ql;
    boolean useJpql;
    Class result;
    int first = 0;
    int max = 1000000;
    /**
     * Creates a new instance of Query
     */
    public Query(EntityManager e,String n,boolean u, String s,Class r) {
        em = e; name = n; useJpql = u; ql = s; result =r;
    }

    public List getResultList() throws IOException, PersistenceException {
        Object[] obs = em.connection.getResults(em,ql,first,max);
        ArrayList al = new ArrayList(obs.length);
        for (int j=0;j<obs.length;j++)
            al.add(obs[j]);
        return al;
    }

    public Object getSingleResult() throws IOException, PersistenceException {
        return em.connection.getResults(em,ql,0,1)[0];
    }

    public int executeUpdate() throws IOException, PersistenceException {
        return em.connection.act(em,ql);
    }

    public Query setMaxResults(int maxResult) {
        max = maxResult;
        return this;
    }

    public Query setFirstResult(int startPosition) {
        first = startPosition;
        return this;
    }

    public Query setHint(String hintName, Object value) {
        return this;
    }

    public Query setParameter(String name, Object value) {
        return this;
    }

    public Query setParameter(String name, Date value, TemporalType temporalType) {
        return setParameter(name,cast(value,temporalType));
    }

    public Query setParameter(String name, Calendar value, TemporalType temporalType) {
        return setParameter(name,cast(value,temporalType));
    }

    public Query setParameter(int position, Object value) {
        return this;
    }

    public Query setParameter(int position, Date value, TemporalType temporalType) {
        return setParameter(position,cast(value,temporalType));
    }

    public Query setParameter(int position, Calendar value, TemporalType temporalType) {
        return setParameter(position,cast(value,temporalType));
    }

    public Query setFlushMode(FlushModeType flushMode) {
        return this;
    }
    
    Object cast(Date val,TemporalType ttyp)
    {
        switch (ttyp)
        {
            case DATE: return new PyrrhoDate(val);
            case TIME: return new PyrrhoTime(val);
            case TIMESTAMP: return val;
        }
        return "";
    }

    Object cast(Calendar val,TemporalType ttyp)
    {
        switch(ttyp)
        {
            case DATE: return new PyrrhoDate(val);
            case TIME: return new PyrrhoTime(val);
            case TIMESTAMP: return val;
        }
        return "";
    }
    
}
