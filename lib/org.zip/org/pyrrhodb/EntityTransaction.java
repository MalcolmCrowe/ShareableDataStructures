/*
 * EntityTransaction.java
 *
 * Created on 25 November 2006, 14:07
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package org.pyrrhodb;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

/**
 *
 * @author Malcolm
 */
public class EntityTransaction {
    private EntityManager em;
    private enum Status { NEW, BEGUN, COMPLETE };
    private Status status = Status.NEW;
    private boolean rollbackOnly = false;
    
    /** Creates a new instance of EntityTransaction */
    EntityTransaction(EntityManager e) {
        em = e;
		em.transaction = this;
    }
    public void begin() throws IOException
    {
		em.connection.Send((byte)6);
        status = Status.BEGUN;
    }
    public void commit() throws IllegalAccessException, InvocationTargetException, IOException, PersistenceException
    {
		if (rollbackOnly)
			throw new PersistenceException("Rollback only set");
		em.flush();
		em.connection.Send((byte)7);
        status = Status.COMPLETE;
    }
    public void rollback() throws IOException
    {
		em.connection.Send((byte)8);
        em.clear();
        status = Status.COMPLETE;
    }
    public boolean getRollbackOnly()
    {
        return rollbackOnly;
    }
    public void setRollbackOnly()
    {
        rollbackOnly = true;
    }
    public boolean isActive()
    { 
        return status==Status.BEGUN; 
    }
}
