/*
 * PersistenceUnitTransactionType.java
 *
 * Created on 25 November 2006, 14:36
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package org.pyrrhodb;

/**
 *
 * @author Malcolm
 */
public enum PersistenceUnitTransactionType { JTA, RESOURCE_LOCAL }
