/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package org.pyrrhodb;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/**
 *
 * @author 66668214
 */
public class Document {
    enum ParseState { StartKey, Key, Colon, StartValue, Comma };
    class Parser { 
        String str; int pos=0; int len;
        Parser(String s){str=s; len = str.length();} 
        Parser(String s,int i,int n) { str=s; pos=i;len=n; }
        boolean match(String s)
        {
            int n = s.length();
            if (pos+n>=len || !s.substring(pos,n).matches(s))
                return false;
            pos += n;
            return true;
        }
        char peek() { return str.charAt(pos); }
        char next() { return str.charAt(pos++); }
    }
    class ParseB { 
        byte[] bytes; int pos=0; int len;
        ParseB(byte[] b){bytes = b; len = b.length;} 
        ParseB(byte[] b,int i,int n) { bytes=b; pos=i;len=n; }
        byte peek() { return bytes[pos]; }
        byte next() { return bytes[pos++]; }
    }
    public HashMap fields = new HashMap();
    private Document() {}
    public Document(String s)throws PersistenceException
    {
        if (s==null)
            return;
        s = s.trim();
        int n = s.length();
        if (n==0 || s.charAt(0)!='{')
            throw new PersistenceException("{ expected");
        Parser p = new Parser(s,1,n);
        Fields(p,false);
        if (p.pos!=p.len)
            throw new PersistenceException("unpasrsed input at "+(p.pos-1));
    }
    private void Fields(Parser p, boolean arr) throws PersistenceException {
        ParseState state = arr?ParseState.StartValue:ParseState.StartKey;
      StringBuilder kb = null;
      while (p.pos<p.len)
      {
          char c = p.next();
          switch(state) {
              case StartKey:
                  kb = new StringBuilder();
                  if (Character.isWhitespace(c))
                      continue;
                  if (c=='}' && fields.isEmpty())
                      return;
                  if (c!='"')
                      throw new PersistenceException("\" expected at "+(p.pos-1));
                  state = ParseState.Key;
                  continue;
              case Key:
                  if (c=='"')
                      c = GetEscape(p);
                      if (arr && !Character.isDigit(c))
                          throw new PersistenceException("Expected digit at "+(p.pos-1));
                      kb.append(c);
                  continue;
              case Colon:
                  if (Character.isWhitespace(c))
                      continue;
                  if (c!=':')
                      throw new PersistenceException(": expected at "+(p.pos-1));
                  state = ParseState.StartValue;
                  continue;
              case StartValue:
                 if (Character.isWhitespace(c))
                      continue;
                  if (c==']' && fields.isEmpty())
                      return;
                  fields.put(arr?(""+fields.size()):kb.toString(),GetValue(p));
                  state= ParseState.Comma;
                  continue;
              case Comma:
                 if (Character.isWhitespace(c))
                      continue;
                 if (c==(arr?']':'}'))
                     return;
                 if (c!=',')
                     throw new PersistenceException(", expected at "+(p.pos-1));
                 state = arr?ParseState.StartValue:ParseState.StartKey;
          }
      }
      throw new PersistenceException("Incomplete syntax at "+(p.pos-1));
    }
    private char GetEscape(Parser p) throws PersistenceException
    {
        if (p.pos<p.len)
        {
            char c = p.next();
            switch(c)
            {
                case '\\':
                case '/':
                case '"': return c;
                case 'b': return '\b';
                case 'f': return '\f';
                case 'n': return '\n';
                case 'r': return '\r';
                case 't': return '\t';
                case 'u':
                case 'U':
                {
                    int v = 0;
                    for (int j=0;j<4;j++)
                        v = (v<<4)+GetHex(p);
                    return (char)v;
                }
            }
        }
         throw new PersistenceException("illegal escape");     
    }
 
    private int GetHex(Parser p) throws PersistenceException
    {
        if (p.pos<p.len)
        {
            char c = p.next();
            if (c>='0' && c<='9')
                return c-'0';
            if (c>='a' && c<='f')
                return c-'a';
            if (c>='A' && c<='F')
                return c-'A';
        }
        throw new PersistenceException("hex digit expected at "+(p.pos-1));  
    }
    private Object GetValue(Parser p) throws PersistenceException
    {
        if (p.pos<p.len)
        {
            char c = p.next();
            if (c=='"')
                return GetString(p);
            if (c=='{')
            {
                Document d = new Document();
                d.Fields(p,false);
                return d;
            }
            if(c=='[')
            {
                Document d = new Document();
                d.Fields(p,true);
                return d;                
            }
            if (p.match("true"))
                return true;
            if (p.match("false"))
                return false;
            if (p.match("null"))
                return null;
            boolean sg = c=='-';
            if (sg && p.pos<p.len)
                c = p.next();
            long whole = 0;
            if (c=='0')
                c = p.next();
            else if (Character.isDigit(c))
            {
                p.pos--;
                whole = GetHex(p);
                while(p.pos<p.len && Character.isDigit(p.peek()))
                    whole = whole*10 +GetHex(p);
            } else
                throw new PersistenceException("value expected at "+(p.pos-1));
            if (p.pos>=p.len || (p.peek()!='.'&& p.peek()!='e' && p.peek()!='E'))
                return sg? -whole: whole;
            int scale = 0;
            if (p.peek()=='.')
            {
                if (++p.pos>=p.len || !Character.isDigit(p.peek()))
                    throw new PersistenceException("decimal part expected");
                while (p.pos<p.len && Character.isDigit(p.peek()))
                {
                    whole = whole*10 + GetHex(p);
                    scale++;
                }
            }
            if (p.pos>=p.len || (p.peek()!='e' && p.peek()!='E'))
            {
              BigDecimal m = new BigDecimal(whole).movePointLeft(scale);
              return sg? m.negate():m;  
            }
            if (++p.pos>=p.len)
                throw new PersistenceException("exponent part expected");
            boolean esg = p.peek()=='-';
            if ((p.peek()=='-' || p.peek()=='+')&&(++p.pos>=p.len || !Character.isDigit(p.peek())))
                throw new PersistenceException("exponent part expected");
            int exp=0;
            while (p.pos<p.len && Character.isDigit(p.peek()))
                exp = exp*10+GetHex(p);
            if (esg)
                exp = -exp;
            double dr = whole*Math.pow(10.0,exp-scale);
            return sg?-dr:dr;
        }
        throw new PersistenceException("value expected at "+(p.pos-1));
    }
    String GetString(Parser p) throws PersistenceException
    {
        StringBuilder sb = new StringBuilder();
        while (p.pos<p.len)
        {
            char c = p.next();
            if (c=='"')
                return sb.toString();
            if (c=='\\')
                c = GetEscape(p);
            sb.append(c);
        }
        throw new PersistenceException("non-terminated string "+(p.pos-1));
    }
    Document(byte[] b, int off) throws UnsupportedEncodingException
    {
         int n = GetInt(b,off);
         ParseB p = new ParseB(b,off+4,off+n-1);
         while (p.pos<p.len)
         {
             byte t = p.next();
             int c = 0;
             int s = p.pos;
             while (p.pos<p.len && p.next()!=0)
                 c++;
             String key = new String(p.bytes,s,c,"UTF-8"); 
             fields.put(key,GetValue(t,p));
         }
    }
    static int GetInt(byte[] bytes,int pos) 
    {
        return bytes[pos] + (bytes[pos+1]<<8)+ (bytes[pos+2]<<16)+(bytes[pos+4]<<24);
    }
    static int GetInt(ParseB p)
    {
        int r = GetInt(p.bytes,p.pos);
        p.pos += 4;
        return r;
    }
    static long GetLong(ParseB p)
    {
        long r = GetInt(p);
        r += ((long)GetInt(p))<<32;
        return r;
    }
    static String GetString(ParseB p) throws UnsupportedEncodingException
    {
        int n = GetInt(p);
        String s = new String(p.bytes,p.pos,n-1,"UTF-8");
        p.pos+=n;
        return s;
    }
    static Object GetValue(byte typ,ParseB p) throws UnsupportedEncodingException
    {
        switch(typ)
        {
            case 1: return Double.longBitsToDouble(GetLong(p));
            case 2: return GetString(p);
            case 3:
            case 4: {
                Document d = new Document(p.bytes,p.pos);
                p.pos += GetInt(p.bytes,p.pos);
            }
            case 5: {
                int n = GetInt(p.bytes,p.pos);
                byte[] r = new byte[n];
                for (int j=0;j<n;j++)
                    r[j] = p.bytes[p.pos+j+4];
                p.pos+=n;
                return r;
            }
            case 7: {
                byte[] r = new byte[12];
                for (int j=0;j<12;j++)
                    r[j] = p.bytes[p.pos+j+4];
                p.pos+=12;
                return new ObjectId(r);
            }
            case 8: return p.next()!=0;
            case 9: return GetLong(p);
            case 16: return GetInt(p);
            case 18: return GetLong(p);
        }
        return new byte[0];
    }
    static void Field(Object v,StringBuilder sb)
    {
        if (v==null)
            sb.append("null");
        else if (v instanceof String)
        {
            sb.append('"');sb.append(v); sb.append('"');
        }
        else
            sb.append(v.toString());
    }
    @Override
    public String toString()
    {
        StringBuilder sb = new StringBuilder("{");
        String comma = "";
        Set set = fields.entrySet();
        Iterator it = set.iterator();
        while (it.hasNext())
        {
            Map.Entry e = (Map.Entry)it.next();
            sb.append(comma); comma = ",";
            sb.append('"');
            sb.append(e.getKey());
            sb.append("\": ");
            Field(e.getValue(),sb);
        }
        sb.append("}");
        return sb.toString();
    }
}