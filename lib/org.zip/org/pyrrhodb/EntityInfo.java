/*
 * EntityInfo.java
 *
 * Created on 24 November 2006, 19:11
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package org.pyrrhodb;

import java.lang.reflect.*;

// Pyrrho Database Engine by Malcolm Crowe at the University of the West of Scotland
// (c) Malcolm Crowe, University of the West of Scotland 2004-2011
//
// This software is without support and no liability for damage consequential to use
// You can view and test this code
// All other use or distribution or the construction of any product incorporating this technology
// requires a license from the University of the West of Scotland

// OPEN SOURCE EDITIONS

public class EntityInfo {
    EntityType type;
    Object entity;
    private Object[] cache = null;
    /**
     * Creates a new instance of EntityInfo
     */
    public EntityInfo(EntityType tp,Object e) throws IllegalAccessException,InvocationTargetException, InstantiationException  {
        type = tp;
        entity = tp.clas.newInstance();
        for (int j=0;j<tp.cols.length;j++)
        {
            FieldInfo fi = tp.cols[j];
            if (fi.field!=null)
                fi.field.set(entity,fi.field.get(e));
            else
                fi.setMeth.invoke(e,fi.getMeth.invoke(e));
        }
    }
    void revert(EntityType et) throws IllegalAccessException,InvocationTargetException {
        for (int j=0;j<et.cols.length; j++)
            et.cols[j].getMeth.invoke(entity,cache[j]);
    }
    void setCache(EntityType et,Object obj) throws IllegalAccessException,
        InvocationTargetException {
        if (cache==null)
            cache = new Object[et.cols.length];
        for (int j=0;j<et.cols.length;j++)
            cache[j]=et.cols[j].getMeth.invoke(obj);
            
    }
}
