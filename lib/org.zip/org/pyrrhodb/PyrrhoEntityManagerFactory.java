/*
 * PyrrhoEntityManagerFactory.java
 *
 * Created on 23 November 2006, 21:01
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package org.pyrrhodb;

import java.util.Map;

/**
 *
 * @author Malcolm
 */
public class PyrrhoEntityManagerFactory extends EntityManagerFactory {
    String name;
    Map properties;
    PyrrhoEntityManagerFactory(String n,Map map)
    {
        name = n; properties = map;
    }
    
    public static EntityManager createEntityManager() {
        return null;
    }

    public static EntityManager createEntityManager(Map map) {
        return null;
    }

    public static void close() {
    }

    public static boolean isOpen() {
        return false;
    }
    
}
