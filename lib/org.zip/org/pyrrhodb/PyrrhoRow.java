/*
 * PyrrhoRow.java
 *
 * Created on 07 October 2006, 13:03
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package org.pyrrhodb;
import java.lang.reflect.*;

/**
 *
 * @author Malcolm
 */
public class PyrrhoRow {
    public PyrrhoTable table;
    public CellValue[] data;
    /** Creates a new instance of PyrrhoRow */
    public PyrrhoRow(PyrrhoTable t) {
        table = t;
        data = new CellValue[t.cols.length];
        t.Rows.add(this);
    }
}
