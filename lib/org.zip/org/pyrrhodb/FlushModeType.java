/*
 * FlushModeType.java
 *
 * Created on 25 November 2006, 14:04
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package org.pyrrhodb;

/**
 *
 * @author Malcolm
 */
public enum FlushModeType { AUTO, COMMIT }

