package org.pyrrhodb;
import java.util.*;

public class PyrrhoTime
{
	public long hours;
	public long minutes;
	public long seconds;
	public long ticks;
	public static long TicksPerSecond()
	{
		return 10000000;
	}
	public PyrrhoTime(long t)
	{
		ticks = t;
		seconds = ticks / PyrrhoTime.TicksPerSecond();
		minutes = seconds / 60; seconds = seconds % 60;
		hours = minutes / 60; minutes = minutes % 60;
	}
        public PyrrhoTime(Date d)
        {
            hours = d.getHours();
            minutes = d.getMinutes();
            seconds = d.getSeconds();
        }
        public PyrrhoTime(Calendar c)
        {
            hours = c.get(Calendar.HOUR);
            minutes = c.get(Calendar.MINUTE);
            seconds = c.get(Calendar.SECOND);
        }
	public String toString()
	{
		return String.format("TIME'%02d:%02d:%02d'",hours,minutes,seconds);	
        }
}
