/*
 * PyrrhoDate.java
 *
 * Created on 28 November 2006, 09:00
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package org.pyrrhodb;

import java.text.SimpleDateFormat;
import java.util.*;

/**
 *
 * @author crow-ci0
 */
public class PyrrhoDate {
    Calendar cal;
    /** Creates a new instance of PyrrhoDate */
    public PyrrhoDate(Date d) {
        cal = new GregorianCalendar(d.getYear(),d.getMonth(),d.getDay());
    }
    public PyrrhoDate(Calendar c) {
        cal = c;
    }
    public String toString()
    {
        return String.format("DATE'%F'",cal);
    }
}
