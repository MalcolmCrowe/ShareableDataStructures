/*
 * PyrrhoTimeSpan.java
 *
 * Created on 27 November 2006, 16:08
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package org.pyrrhodb;

/**
 *
 * @author crow-ci0
 */
public class PyrrhoTimeSpan {
    long miniticks;
    /** Creates a new instance of PyrrhoTimeSpan */
    public PyrrhoTimeSpan(long m) {
        miniticks = m;
    }
}
