/*
 * PyrrhoEntity.java
 *
 * Created on 23 November 2006, 21:14
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package org.pyrrhodb;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;

/**
 *
 * @author Malcolm
 */
public class EntityType {
    Class clas;
    String table;
    FieldInfo key;
    FieldInfo[] cols;
    Annotation[] anns;
    public EntityType(Class cl,String t,FieldInfo k,FieldInfo[] c) {
        clas = cl; table=t; key = k; cols = c;
        anns = cl.getAnnotations();
    }
    
}
