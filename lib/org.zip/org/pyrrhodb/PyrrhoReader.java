/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.pyrrhodb;

/**
 *
 * @author Malcolm
 */
public class PyrrhoReader {

    PyrrhoStatement stmt;
    PyrrhoTable schema = null;
    PyrrhoRow row = null;
    int types[] = null;
    CellValue cells[] = null;  // 4.2
    int off = 0;
    boolean AtEof = true;
    boolean AtBof = true;

    private PyrrhoReader(PyrrhoStatement s) {
        stmt = s;
    }

    static PyrrhoReader New(PyrrhoStatement s) throws PersistenceException {
        try {
            int p = s.conn.Receive();
            if (p != 13) {
                return null;
            }
            int ncols = s.conn.GetInt();
            if (ncols == 0) {
                return null;
            }
            s.conn.GetString();
            PyrrhoReader rdr = new PyrrhoReader(s);
            rdr.schema = new PyrrhoTable(ncols);
            s.conn.GetSchema(rdr.schema);
            int k = 0;
            rdr.row = new PyrrhoRow(rdr.schema);
            return rdr;
        } catch(PersistenceException e){
            throw e;
        }
        catch (Exception e) {
            throw new PersistenceException("08006");
        }
    }

    public void Reset() throws PersistenceException
    {
        try {
        stmt.conn.Send((byte)14);
        int p = stmt.conn.Receive();
        if (p!=11)
            throw new PersistenceException("20000");
        } catch(Exception e) {
            throw new PersistenceException("08006");
        }
    }

    public boolean Read()
    {
        for (int j=0;j<schema.cols.length;j++)
            if (!GetCell(j))
                return false;
        return true;
    }

    private boolean GetCell(int cx) {
        if (cells != null) {
            row.data[cx] = cells[off++];
            if (off == cells.length) {
                cells = null;
            }
            return true;
        }
        try {
            stmt.conn.Send((byte) 16);
            int p = stmt.conn.Receive();
            if (p != 10) {
                return false;
            }
            int n = stmt.conn.GetInt();
            if (n == 0) {
                return false;
            }
            cells = new CellValue[n];
            off = 0;
            int j = cx;
            for (int i = 0; i < n; i++) {
                PyrrhoColumn c = schema.cols[j];
                cells[i] = stmt.conn.GetCell(c.dataTypeName,c.type);
                if (++j==schema.cols.length)
                    j = 0;
            }
            row.data[cx] = cells[off++];
            return true;
        } 
        catch (Exception e) {
            return false;
        }
    }
    int Find(String c)
    {
        for (int i=0;i<schema.cols.length;i++)
            if (c.matches(schema.cols[i].name))
                return i;
        return -1;
    }
}
