package org.pyrrhodb;
import java.lang.*;
import java.io.*;
import java.net.*;
// Pyrrho Database Engine by Malcolm Crowe at the University of the West of Scotland
// (c) Malcolm Crowe, University of the West of Scotland 2004-2011
//
// This software is without support and no liability for damage consequential to use
// You can view and test this code
// All other use or distribution or the construction of any product incorporating this technology 
// requires a license from the University of the West of Scotland

// OPEN SOURCE EDITIONS

// This class provides encryption on the stream to the server
// Encryption is currently used for connection strings only
public class Crypt
{
        // The input stream
	PyrrhoInputStream is;
        // The output stream
	PyrrhoOutputStream os;
        // The encryption state
	long state;
        // The constant multiplier used for encryption
	long mult = 73928681;
	public Crypt(PyrrhoInputStream i,PyrrhoOutputStream o)
	{
		is = i; os = o;
	}
        // Encrypt a byte
	byte Encrypt(byte b)
	{
		byte c = (byte)(b + state);
		state = (state*mult)>>8;
                if (state==0)
                    state = 1;
		return c;
	}
        // Decrypt a byte
	byte Decrypt(byte c)
	{
		byte b = (byte)(c - state);
		state = (state*mult)>>8;
                if (state==0)
                    state = 1;
		return b;
	}
        // write an array of bytes with encryption
	public void write(byte[] b, int n) throws IOException // b is in cleartext
	{
		for (int j = 0; j < n; j++)
			b[j] = Encrypt(b[j]);
		os.write(b, 0, n); // b is in cyphertext
	}
        // write a single byte with encryption
	public void write(byte b) throws IOException
	{
		os.write(Encrypt(b));
	}
        // send an int with encryption
	public void PutInt(int n) throws IOException
	{
		byte[] b = new byte[4];
		b[0] = (byte)(n >> 24);
		b[1] = (byte)(n >> 16);
		b[2] = (byte)(n >> 8);
		b[3] = (byte)n;
		write(b, 4);
	}
        // send a string with encryption
	public void PutString(String text) throws IOException
	{
		byte[] bytes = text.getBytes();
		int n = bytes.length;
		PutInt(n);
		write(bytes, n);
	}
        // send a protocol byte and a string with encryption
	public void Send(byte proto, String text) throws IOException
	{
		write(proto);
		PutString(text);
		os.flush();
	}
        // send a protocol byte with encryption
	public void Send(byte proto) throws IOException
	{
		write(proto);
		os.flush();
	}
}
