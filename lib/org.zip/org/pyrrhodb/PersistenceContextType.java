/*
 * PersistenceContextType.java
 *
 * Created on 03 January 2007, 15:02
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package org.pyrrhodb;

/**
 *
 * from Java EE 5 specification
 */
public enum PersistenceContextType {
    EXTENDED, TRANSACTION
}
