/*
 * FetchType.java
 *
 * Created on 29 December 2006, 17:31
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package org.pyrrhodb;

/**
 *
 * @author Malcolm
 */
public enum FetchType {
    EAGER, LAZY
}
