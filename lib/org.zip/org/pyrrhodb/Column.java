/*
 * Column.java
 *
 * Created on 25 November 2006, 13:52
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package org.pyrrhodb;

import java.lang.annotation.*;

/**
 *
 ** from Java EE 5 specifications (javax.persistence)
 */
@Target({ElementType.FIELD,ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
public @interface Column {
    public String columnDefinition() default "";
    public boolean insertable() default true;
    public String name() default "";
    public boolean unique() default false;
    public boolean nullable() default true;
    public boolean updatable() default true;
    public String table() default "";
    public int length() default 255;
    public int precision() default 0;
    public int scale() default 0;
}
