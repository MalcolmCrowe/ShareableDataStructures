/*
 * CascadeType.java
 *
 * Created on 29 December 2006, 17:29
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package org.pyrrhodb;

/**
 * from Java EE 5 specifications (javax.persistence)
 */
public enum CascadeType {
    ALL, MERGE, PERSIST, REFRESH, REMOVE
}
