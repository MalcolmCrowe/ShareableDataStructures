/*
 * EntityFinder.java
 *
 * Created on 25 November 2006, 18:35
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package org.pyrrhodb;
// Pyrrho Database Engine by Malcolm Crowe at the University of the West of Scotland
// (c) Malcolm Crowe, University of the West of Scotland 2004-2011
//
// This software is without support and no liability for damage consequential to use
// You can view and test this code
// All other use or distribution or the construction of any product incorporating this technology
// requires a license from the University of the West of Scotland

// OPEN SOURCE EDITIONS

public class EntityFinder {
    
    Class type;
    Object key;
    /** Creates a new instance of EntityFinder */
    public EntityFinder(Class t,Object k) {
        type = t; key = k;
    }
    public EntityFinder() {}
    public boolean equals(Object obj) {
        EntityFinder that = (EntityFinder)obj;
        return type==that.type && key.equals(that.key);
    }
}
