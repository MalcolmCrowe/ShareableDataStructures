/*
 * EntityManagerFactory.java
 *
 * Created on 23 November 2006, 21:01
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package org.pyrrhodb;

import java.util.*;
import java.lang.*;
import java.lang.reflect.*;

/**
 *
 * @author Malcolm
 */
public class EntityManagerFactory {

    static PersistenceUnit pu = null;

    public static EntityManager createEntityManager() {
        Context();
        return new EntityManager(pu,new HashMap());
    }

    public static EntityManager createEntityManager(Map map) {
        Context();
        return new EntityManager(pu,map);
    }

    public static void close() {
    }

    public static boolean isOpen() {
        return false;
    }
    public static void Context()
    {
        if (pu!=null)
            return;
         try{
            Class cl = Class.forName(Thread.currentThread().getStackTrace()[3].getClassName());
             
            for(Field f : cl.getDeclaredFields())
            {
                pu = (PersistenceUnit)f.getAnnotation(PersistenceUnit.class);
                if (pu!=null)
                    break;
            }
         } catch(Exception e)
         {
             e.printStackTrace();
         }
    }
    
}
