/*
 * TemporalType.java
 *
 * Created on 25 November 2006, 14:18
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package org.pyrrhodb;

/**
 *
 * @author Malcolm
 */
public enum TemporalType { DATE, TIME, TIMESTAMP }

