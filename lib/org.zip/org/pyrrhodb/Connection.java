/*
 * Connection.java
 *
 * Created on 25 November 2006, 18:22
 *
// Pyrrho Database Engine by Malcolm Crowe at the University of the West of Scotland
// (c) Malcolm Crowe, University of the West of Scotland 2004-2011
//
// This software is without support and no liability for damage consequential to use
// You can view and test this code
// All other use or distribution or the construction of any product incorporating this technology
// requires a license from the University of the West of Scotland

// OPEN SOURCE EDITIONS
 */
package org.pyrrhodb;

import java.lang.reflect.*;
import java.lang.annotation.*;
import java.math.BigDecimal;
import java.net.*;
import java.io.*;
import java.util.*;
import java.sql.Statement;
import java.sql.SQLException;

/**
 *
 * @author malcolm@pyrrhodb.com
 *
 * This class provides a connection to the Open Source Pyrrho DBMS server only
 */
public final class Connection {
    // Two streams for server communications: input stream

    PyrrhoInputStream inp;
    // Output stream for server communication
    PyrrhoOutputStream out;
    // Open source Pyurrho version of encryption
    Crypt crypt;
    // The name of a results set
    String resultsName;
    // Columns in a results set
    PyrrhoTable schema = null;
    // Connection properties: Host, Port, Files, User etc
    Map<String, String> properties;
    java.sql.SQLWarning warn = null;
    java.sql.SQLException exc = null;

    /** Creates a new instance of Connection */
    public Connection(Map<String, String> props) throws IOException {
        properties = props;
        String hostName = properties.get("Host");
        if (hostName == null) {
            hostName = "::1";
        }
        String ps = properties.get("Port");
        if (ps == null) {
            ps = "5433";
        }
        Socket sock = new Socket(hostName, Integer.parseInt(ps));
        out = new PyrrhoOutputStream(sock.getOutputStream());
        inp = new PyrrhoInputStream(sock.getInputStream());
        crypt = new Crypt(inp, out);
        crypt.state = GetLong();
        Send((byte) 0);
        for (Map.Entry en : properties.entrySet()) {
            String key = (String) en.getKey();
            if (key.compareTo("User") == 0) {
                crypt.Send((byte) 21, (String) en.getValue());
            } else if (key.compareTo("Files") == 0) {
                crypt.Send((byte) 22, (String) en.getValue());
            } else if (key.compareTo("Authority") == 0) {
                crypt.Send((byte) 23, (String) en.getValue());
            }
        }
        crypt.Send((byte) 24);
        try {
            int p = Receive();
            if (p != 60) {
                throw new IOException("Could not open connection");
            }
        } catch (Exception ex) {
            throw new IOException(ex.getMessage());
        }
    }

    public static Connection getConnection(String host,String dbname,String user, String role) throws IOException
    {
        Map<String,String> map = new HashMap<String,String>();
        map.put("Host",host);
        map.put("Files", dbname);
        map.put("User", user);
        map.put("Authority",role);
        return new Connection(map);
    }

    public Statement createStatement()
    {
        return new PyrrhoStatement(this);
    }
    // Get the results for an sql statement

    public Object[] getResults(EntityManager em, String sql, int first, int count) throws IOException, PersistenceException {
		try {
        out.write((byte) 21);
        PutString(sql);
        out.flush();
        int p = Receive();
        if (p != 13) {
            return null;
        }
        int ncols = GetInt();
        if (ncols == 0) {
            return null;
        }
        resultsName = GetString();
        schema = new PyrrhoTable(ncols);
        GetSchema(schema);
        if (ncols != 1) {
            throw new PersistenceException("1 column expected");
        }
        if (first > 0) {
            out.write((byte) 3);
            PutInt(first);
        }
        ArrayList al = new ArrayList();
        for (int j = 0; j < count; j++) {
            String tname = schema.cols[j].dataTypeName;
            int flag = schema.cols[j].type;
            Send((byte) 4);
            p = Receive();
            if (p != 14) {
                break;
            }
            byte b = (byte) inp.read();
            if (b == 0) {
                al.add(DBNull.value);
            } else {
                if (b==2)
                {
                    tname = GetString();
                    flag = GetInt();
                }
                switch (flag & 0xf) {
                    case 0:
                        al.add(DBNull.value);
                        break;
                    case 1:
                        al.add(Long.decode(GetString()));
                        break;
                    case 2:
                        al.add(Double.valueOf(GetString()));
                        break;
                    case 3:
                        al.add(GetString());
                        break;
                    case 4:
                        al.add(GetDateTime());
                        break;
                    case 5:
                        al.add(GetBlob());
                        break;
                    case 6:
                        al.add(GetRow());
                        break;
                    case 7:
                        al.add(GetArray());
                        break;
                    case 8:
                        al.add(Double.valueOf(GetString()));
                        break;
                    case 9: {
                        int x = GetInt();
                        al.add(x > 0);
                        break;
                    }
                    case 10:
                        al.add(GetInterval());
                        break;
                    case 11:
                        al.add(GetTimeSpan());
                        break;
                    case 12:
                        al.add("UDType?");
                        break;
                    case 13:
                        al.add(GetDateTime());
                        break;
                    case 14:
                        al.add(GetTable());
                        break;
                }
            }
        }
        Object[] r = new Object[al.size()];
        for (int j = 0; j < al.size(); j++) 
            r[j] = al.get(j);
        return r;
		} catch(PersistenceException ex)
		{
			em.transaction = null;
			throw(ex);
		}
    }

    public int act(EntityManager em, String sql) throws IOException,PersistenceException {
        out.write((byte) 28);
        PutString(sql);
        out.flush();
        int p = Receive();
        if (p == 11) {
            return GetInt();
        }
        return -1;
    }

    String FieldType(Class t) {
        if (t.isEnum()) {
            return "$" + t.getName();
        }
        if ((!t.isPrimitive()) && t.getAnnotation(Entity.class) != null) {
            return t.getName();
        }
        t = t.getComponentType();
        if (t != null && t.getAnnotation(Entity.class) != null) {
            return t.getName();
        }
        return "";
    }
    // Cast Pyrrho database types to something suitable for Java

    Object Cast(EntityManager em, HashMap ht, Class type, Object data) throws IOException, InstantiationException, IllegalAccessException, InvocationTargetException {
        if (type.isInstance(data)) {
            return data;
        }
        if (type.getName().compareTo("int") == 0) {
            return ((Long) data).intValue();
        }
        if (type.getName().compareTo("long") == 0) {
            return ((Long) data).longValue();
        }
        if (type.getName().compareTo("byte") == 0) {
            return ((Long) data).byteValue();
        }
        if (type.getName().compareTo("float") == 0) {
            return ((Double) data).floatValue();
        }
        if (type.getName().compareTo("double") == 0) {
            return ((Double) data).doubleValue();
        }
        if (type.getName().compareTo("boolean") == 0) {
            return ((Boolean) data).booleanValue();
        }
        return null;
    }
    // Rearrange setters if required to match the name order
    // in the results returned by the server

    FieldInfo[] Rearrange(FieldInfo[] fi, String[] cs) {
        FieldInfo[] r = new FieldInfo[fi.length];
        for (int j = 0; j < cs.length; j++) {
            for (int k = 0; k < fi.length; k++) {
                if (fi[j].name.compareTo(cs[k]) == 0) {
                    r[k] = fi[j];
                    break;
                }
            }
        }
        return r;
    }

    // Send an int to the server

    void PutInt(int n) throws IOException {
        byte[] b = new byte[4];
        b[0] = (byte) (n >> 24);
        b[1] = (byte) (n >> 16);
        b[2] = (byte) (n >> 8);
        b[3] = (byte) n;
        out.write(b);
    }
    // Send a long to the server

    void PutLong(long n) throws IOException {
        byte[] b = new byte[8];
        b[0] = (byte) (n >> 56);
        b[1] = (byte) (n >> 48);
        b[2] = (byte) (n >> 40);
        b[3] = (byte) (n >> 32);
        b[4] = (byte) (n >> 24);
        b[5] = (byte) (n >> 16);
        b[6] = (byte) (n >> 8);
        b[7] = (byte) n;
        out.write(b);
    }

    void PutNHashMap(HashMap ht) throws IOException {
        if (ht == null) {
            PutInt(0);
            return;
        }
        PutInt(ht.size());
        Iterator it = ht.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry s = (Map.Entry) it.next();
            PutString((String) s.getKey());
            Object v = s.getValue();
            if (v instanceof String) {
                PutString("'" + (String) v + "'");
            } else if (v instanceof Date) {
                PutString(String.format("TIMESTAMP'%1$F %1$T'", (Date) v));
            } else {
                PutString(v.toString());
            }
        }
    }

    void PutPHashMap(HashMap ht) throws IOException {
        if (ht == null) {
            PutInt(0);
            return;
        }
        PutInt(ht.size());
        Iterator it = ht.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry s = (Map.Entry) it.next();
            PutInt((int) (Integer) s.getKey());
            Object v = s.getValue();
            if (v instanceof String) {
                PutString("'" + (String) v + "'");
            } else if (v instanceof Date) {
                PutString(String.format("TIMESTAMP'%1$F %1$T'", (Date) v));
            } else {
                PutString(v.toString());
            }
        }
    }
    // get an int from the server

    int GetInt() throws IOException {
        byte[] b = new byte[4];
        inp.read(b);
        int n = 0;
        for (int j = 0; j < 4; j++) {
            n = (n << 8) + (((int) b[j]) & 0xff);
        }
        return n;
    }
    // get a long from the server

    long GetLong() throws IOException {
        byte[] b = new byte[8];
        int m = inp.read(b);
        long n = 0;
        for (int j = 0; j < 8; j++) {
            n = (n << 8) + (((int) b[j]) & 0xff);
        }
        return n;
    }
    // get a string from the server

    String GetString() throws IOException {
        int n = GetInt();
        byte[] b = new byte[n];
        if (n > 0) {
            inp.read(b);
        }
        return new String(b);
    }
    // get a Blob from the server

    byte[] GetBlob() throws IOException {
        int n = GetInt();
        byte[] b = new byte[n];
        inp.read(b);
        return b;
    }
    // get a Row from the server

    PyrrhoRow GetRow() throws IOException,PersistenceException {
        int n = GetInt();
        PyrrhoTable t = new PyrrhoTable(n);
        PyrrhoRow r = new PyrrhoRow(t);
        for (int j = 0; j < n; j++) {
            String cn = GetString();
            String tn = GetString();
            int fl = GetInt();
            t.cols[j] = new PyrrhoColumn(cn,tn,fl);
            r.data[j] = GetCell(tn,fl);
        }
        return r;
    }
    
    void GetSchema(PyrrhoTable t) throws IOException
    {
        for (int j = 0; j < t.cols.length; j++) {
            String cn = GetString();
            String tn = GetString();
            PyrrhoColumn c = new PyrrhoColumn(cn,tn, GetInt());
            t.cols[j] = c;
        }
    }
    
    PyrrhoTable GetTable() throws IOException, PersistenceException {
            int n = GetInt();
            if (n==0)
                return null;
            String s = GetString();
            PyrrhoTable dt = new PyrrhoTable(n);
            GetSchema(dt);
            int nrows = GetInt();
            for (int j=0;j<nrows;j++)
                dt.Rows.add(GetRow());
            return dt;
    }
    // get an array from the server

    PyrrhoArray GetArray() throws IOException, PersistenceException {
        String atp = GetString();
        String tn = GetString();
        int fl = GetInt();
        int n = GetInt();
        PyrrhoArray a = new PyrrhoArray(n);
        a.kind = atp;
        if (atp.compareTo("TABLE") == 0) {
            for (int j = 0; j < n; j++) {
                a.data[j] = GetRow();
            }
        } else {
            for (int j = 0; j < n; j++) {
                a.data[j] = GetCell(tn,fl);
            }
        }
        return a;
    }
    // get a date or timestamp from the server

    Date GetDateTime() throws IOException {
        return new Date(GetLong() / 10000);
    }
    // get a TimeSpan from the server

    PyrrhoTimeSpan GetTimeSpan() throws IOException {
        return new PyrrhoTimeSpan(GetLong());
    }
    // get a time interval (unbased difference between two dates)

    PyrrhoInterval GetInterval() throws IOException {
        PyrrhoInterval iv = new PyrrhoInterval();
        iv.years = (int) GetLong();
        iv.months = (int) GetLong();
        iv.ticks = GetLong();
        return iv;
    }
    // get a list of strings from the server

    String[] GetStrings() throws IOException {
        int n = GetInt();
        String[] obs = new String[n];
        for (int j = 0; j < n; j++) {
            obs[j] = GetString();
        }
        return obs;
    }
    
    CellValue GetCell(String tn,int flag) throws IOException,PersistenceException
    {
        CellValue r = new CellValue(tn);
        int b = Receive();
        if (b==0)
            return r;
        if (b==2)
        {
            r.subType = GetString();
            flag = GetInt();
        }
        switch (flag&0xf)
        {
            case 0: return null;
            case 1: r.val = Long.parseLong(GetString()); break;
            case 2: r.val = new BigDecimal(GetString()); break;
            case 3: r.val = GetString(); break;
            case 4: r.val = GetDateTime(); break;
            case 5: 
                byte[] bb = GetBlob();
                if (r.subType.matches("DOCUMENT"))
                    r.val = new Document(bb,0);
          //      else if (r.subType== "DOCARRAY") break;
                else if (r.subType.matches("OBJECT"))
                    r.val = new ObjectId(bb);
                else r.val = bb; break;
            case 6: r.val = GetRow(); break;
            case 7: r.val = GetArray(); break;
            case 8: r.val = Double.parseDouble(GetString()); break;
            case 9: r.val = (GetInt()!=0); break;
            case 10: r.val = GetInterval(); break;
            case 11: r.val = GetTimeSpan(); break;
            case 12: r.val = GetRow(); break;
            case 13: r.val = new PyrrhoDate(GetDateTime()); break;
            case 14: r.val = GetTable(); break;  
            default: throw new PersistenceException("bad flag"+flag);
        }
        return r;
    }
    
    // send a protocol byte and a string to the server

    void Send(byte proto, String text) throws IOException {
        out.write(proto);
        PutString(text);
        out.flush();
    }
    // send a protocol byte to the server

    void Send(byte proto) throws IOException {
        out.write(proto);
        out.flush();
    }
    // receive a protocol byte or an exception from the server

    int Receive() throws IOException, PersistenceException {
        int proto = inp.read();
        switch (proto) {
            case -1:
                throw new PersistenceException("2E205");
            case 12:
                throw new PersistenceException(GetString(), GetStrings());
            case 16:
                throw new PersistenceException("2E206", GetStrings());
            case 17:
                throw new PersistenceException(GetString());
            case 19:
                throw new PersistenceException("0N002", GetStrings());
            default:
                return proto;
        }
    }
    // Send a string to the server

    private void PutString(String text) throws IOException {
        byte[] bytes = text.getBytes();
        PutInt(bytes.length);
        out.write(bytes);
    }
    // Deal with server callbacks: not implemented

    Thread Callbacks(String sigs) throws PersistenceException {
        throw new PersistenceException("2E206");
    }
}
