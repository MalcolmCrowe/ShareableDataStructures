/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package org.pyrrhodb;

/**
 *
 * @author 66668214
 */
public class ObjectId {
           byte[] bytes;
        ObjectId(byte[] b)
        {
            bytes = b;
        }
        byte[] ToBytes()
        {
            return bytes;
        }
        static String hex = "0123456789abcdef";
           @Override
        public String toString()
        {
            StringBuilder sb=new StringBuilder();
            sb.append("\"");
            for (byte b : bytes)
            {
                sb.append(hex.charAt((b>>4)&0xf));
                sb.append(hex.charAt(b&0xf));
            }
            sb.append("\"");
            return sb.toString();
        }
}
